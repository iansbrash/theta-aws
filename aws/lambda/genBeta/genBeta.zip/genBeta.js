var AWS = require("aws-sdk");
const jwt = require('jsonwebtoken');
const token = require('./sensitive.js')


AWS.config.update({
    region: "us-east-1",
});
var docClient = new AWS.DynamoDB.DocumentClient();

const authenticateJWT = (jwt_token) => {

    console.log(`in authenticateJWT middleware, jwt_token: ${jwt_token}`);
    console.log(`token: ${token}`)

    if (jwt_token === null) return res.sendStatus(401)

    jwt.verify(jwt_token, token, (err, res) => {
        
        console.log(res)

        if (err) {
            throw "Invalid signature"
        }
        else {
           return res;
        }
    })
}

// HEADERS:
//      discordId
//      validationToken
    //      we first somehow check if that person is in the discord
    //      then we add it to the DB if the person is in the discord
    //      perhaps we use some cryptographic token encoded with a public key to make sure its a valid request
exports.handler = async function(event, context, callback) {        
    console.log('Received event:', JSON.stringify(event, null, 2));

    // A simple request-based authorizer example to demonstrate how to use request 
    // parameters to allow or deny a request. In this example, a request is  
    // authorized if the client-supplied headerauth1 header, QueryString1
    // query parameter, and stage variable of StageVar1 all match
    // specified values of 'headerValue1', 'queryValue1', and 'stageValue1',
    // respectively.

    // Retrieve request parameters from the Lambda function input:
    var headers = event.headers;
    var queryStringParameters = event.queryStringParameters;
    var pathParameters = event.pathParameters;
    var stageVariables = event.stageVariables;
        
    // Parse the input for the parameter values
    var tmp = event.methodArn.split(':');
    var apiGatewayArnTmp = tmp[5].split('/');
    var awsAccountId = tmp[4];
    var region = tmp[3];
    var restApiId = apiGatewayArnTmp[0];
    var stage = apiGatewayArnTmp[1];
    var method = apiGatewayArnTmp[2];
    var resource = '/'; // root resource
    if (apiGatewayArnTmp[3]) {
        resource += apiGatewayArnTmp[3];
    }

    // Make sure request is valid
    if (!headers || !headers.discordId || !headers.token) {
        return {
            "isBase64Encoded": false,
            "statusCode": 400,
            // "headers": { "session": newSession },
            "body": "Invalid Request"
        }
    }

    // Make sure JWT signature is correct (and therefore came from our discord bot)
    try {
        let jwtResult = authenticateJWT(headers.token)
        console.log(jwtResult)
    }
    catch (err) {
        return {
            "isBase64Encoded": false,
            "statusCode": 400,
            "body": "Malformed token"
        }
    }

    return;
        
    // Perform authorization to return the Allow policy for correct parameters and 
    // the 'Unauthorized' error, otherwise.
    var authResponse = {};
    var condition = {};
    condition.IpAddress = {};
    
    const params = {
        TableName: 'liscenseKeys',
        Key:
        {
            "discordId": headers.discordId
        }
    }
    
    let result = await docClient.get(params).promise();
    
    if (result.Item !== undefined && result.Item !== null) {
        console.log(`r.I.s: ${result.Item.session}`)
        if (headers.session === result.Item.session && headers.session !== '') {
            return {
                "isBase64Encoded": false,
                "statusCode": 400,
                // "headers": { "session": newSession },
                "body": "404: Invalid Request"
            }
        }
        else {
            return {
                "isBase64Encoded": false,
                "statusCode": 400,
                // "headers": { "session": newSession },
                "body": "404: Invalid Request"
            }
        }
        
    }
    else {
        return {
            "isBase64Encoded": false,
            "statusCode": 400,
            // "headers": { "session": newSession },
            "body": "404: Invalid Request"
        }
    }
}